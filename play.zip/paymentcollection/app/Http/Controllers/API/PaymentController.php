<?php
   
namespace App\Http\Controllers\API;
   
use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController as BaseController;
use App\Models\Payment;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Validator;
   
class PaymentController extends BaseController
{
  
    public function index()
    {
        $payment = Payment::with('customer','user')->get();
        return $this->sendResponse($payment, 'Payment retrieved successfully.');
    }
    
    public function store(Request $request)
    {
        $input = $request->all();
        $input['user_id'] = Auth::user()->id;
        $validator = Validator::make($input, [
            'customer_id' => 'required',
            'user_id' => 'required',
            'amount' => 'required',
            'payment_by' => 'required',
            'description' => 'required'
        ]);
   
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());       
        }
   
        $payment = Payment::create($input);
   
        return $this->sendResponse($payment, 'Payment created successfully.');
    } 
   
  
    public function show($id)
    {

        $payment = Payment::with('customer','user')->find($id);
  
        if (is_null($payment)) {
            return $this->sendError('Payment not found.');
        }
   
        return $this->sendResponse($payment, 'Payment retrieved successfully.');
    }
    
   
    public function update(Request $request, Payment $payment)
    {
        $input = $request->all();
         $validator = Validator::make($input, [
            'name' => 'required',
            'gender' => 'required',
            'address' => 'required',
            'dob' => 'required',
            'pancard' => 'required',
            'aadharcard' => 'required',
            'amount' => 'required',
            'nominee' => 'required'
        ]);
   
   
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());       
        }
        $payment->name = $input['name'];
        $payment->gender = $input['gender'];
        $payment->address = $input['address'];
        $payment->dob = $input['dob'];
        $payment->pancard = $input['pancard'];
        $payment->aadharcard = $input['aadharcard'];
        $payment->amount = $input['amount'];
        $payment->nominee = $input['nominee'];
        $payment->save();
   
        return $this->sendResponse($payment, 'Payment updated successfully.');
    }
   
   
    public function destroy(Payment $payment)
    {

        $payment->delete();
   
        return $this->sendResponse([], 'Payment deleted successfully.');
    }
}