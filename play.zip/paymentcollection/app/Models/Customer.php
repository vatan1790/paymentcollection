<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\User;
class Customer extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id',  'name',    'gender',  'address', 'dob', 'pancard', 'aadharcard',  'amount',  'nominee', 'agent_id'
    ];

     public function agent()
    {
        return $this->belongsTo(User::class, 'agent_id', 'id');
    }
}