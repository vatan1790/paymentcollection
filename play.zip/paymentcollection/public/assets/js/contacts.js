$(function() {
	'use strict'

	const ps1 = new PerfectScrollbar('#mainContactList', {
		useBothWheelAxes:true,
		suppressScrollX:true,
	});
	
});