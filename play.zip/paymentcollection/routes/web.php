<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\API\CustomerController;
use App\Http\Controllers\PermissionController;

use App\Http\Controllers\API\RegisterController;
/*
|--------------------------------------------------------------------------
| Web Routes 
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::post('saleschart', [App\Http\Controllers\HomeController::class, 'SalesChart'])->name('saleschart');

Route::group(['middleware' => ['auth']], function() {
    Route::resource('users', UserController::class);
    Route::get('users-statuschange/', [UserController::class, 'statuschange'])->name('users-statuschange');
   
    Route::get('customers', [UserController::class, 'customers'])->name('customers');
  
    Route::get('customer-list/', [UserController::class, 'customerlist'])->name('customer-list');

    Route::get('payments/{id}', [UserController::class, 'payments'])->name('payments');
  
    Route::get('payment-list/', [UserController::class, 'paymentlist'])->name('payment-list');
  
    Route::resource('roles', RoleController::class);
    Route::resource('permissions', PermissionController::class);
   
    
    Route::post('/import',[ProductController::class,'import'])->name('import');
    
});

