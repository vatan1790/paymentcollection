<?php $__env->startSection('title'); ?>
<title>Customer</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
      <!-- Page Header -->
      <div class="page-header">
        <div>
            <h2 class="main-content-title tx-24 mg-b-5">Customer</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Customer</li>
            </ol>
        </div>
        
    </div>
    <!-- End Page Header -->

    <!-- Row-->
    <div class="row">
        <div class="col-sm-12 col-xl-12 col-lg-12">
            <div class="card custom-card">
                <div class="card-body">
                    <div>
                   
                        <h6 class="card-title mb-1">Customer</h6>
                        <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e(\Session::get('success')); ?></p>
                            </div>
                        <?php endif; ?>
                      
                    </div>
                    <div class="table-responsive">
                    <table id="exportexample1" class="table-bordered text-nowrap mb-0 table table-bordered border-t0 key-buttons text-nowrap w-100" >
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Agent ID</th>
                                <th>Agent Name</th>
                                <th>Name</th>
                                <th>Gender</th>
                                <th>Address</th>
                                <th>DOB</th>
                                <th>Pancard</th>
                                <th>Adharcard</th>
                                <th>Amount</th>
                                <th>Nominee</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                          
                        
                        </tbody>
                    </table>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Row -->

    </div>
    


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<!-- Data Table js -->
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/jquery.dataTables.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/js/table-data.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/dataTables.responsive.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/dataTables.buttons.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/buttons.bootstrap4.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/jszip.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/pdfmake.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/vfs_fonts.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/buttons.html5.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/buttons.print.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/buttons.colVis.min.js"></script>

 <script>
    var table = '';
    $(document).ready(function () {

        table = $('#exportexample1').DataTable({
            dom: 'lBfrtip',
            buttons: [
               { 
                  extend: 'excel',
                  text: 'Customer Excel Export'
               }
            ],
            lengthMenu: [[25, 100, -1], [25, 100, "All"]],
            processing: true,
            responsive: true,
            serverSide: true,
            ajax: {
                "url": "<?php echo e(route('customer-list')); ?>",
                "type": "get",
            },
            columns: [
                {data: 'id', name: 'id'},
                {data: 'agentid', name: 'agentid'},
                {data: 'agentname', name: 'agentname'},
                {data: 'name', name: 'name'},
                {data: 'gender', name: 'gender'},
                {data: 'address', name: 'address'},
                {data: 'dob', name: 'dob'},
                {data: 'pancard', name: 'pancard'},
                {data: 'aadharcard', name: 'aadharcard'},
                {data: 'amount', name: 'amount'},
                {data: 'nominee', name: 'nominee'},
                {data: 'action', name: 'action', orderable: false, searchable: false},
            ],
            "fnDrawCallback": function () {
            }
        });

    });


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u649628429/domains/vdwebinfotech.in/public_html/paymentcollection/resources/views/customer/index.blade.php ENDPATH**/ ?>