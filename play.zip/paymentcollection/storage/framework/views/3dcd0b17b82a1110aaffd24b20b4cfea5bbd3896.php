<?php $__env->startSection('title'); ?>
<title>Permission</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
      <!-- Page Header -->
      <div class="page-header">
        <div>
            <h2 class="main-content-title tx-24 mg-b-5">Permission</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Permission</li>
            </ol>
        </div>
        
    </div>
    <!-- End Page Header -->

    <!-- Row-->
    <div class="row">
        <div class="col-sm-12 col-xl-12 col-lg-12">
            <div class="card custom-card">
                <div class="card-body">
                    <div>
                   
                        <h6 class="card-title mb-1">Permissions</h6>
                        <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e(\Session::get('success')); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-create')): ?>
                            <span class="float-right">
                                <a class="btn btn-primary" href="<?php echo e(route('permissions.create')); ?>">New Permission</a>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="table-responsive">

                    <table id="exportexample1" class=" table-bordered text-nowrap mb-0 table table-bordered border-t0 key-buttons text-nowrap w-100" >
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th width="280px">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($permission->id); ?></td>
                                    <td><?php echo e($permission->name); ?></td>
                                    <td>
                                        <!-- <a class="btn btn-success" href="<?php echo e(route('permissions.show',$permission->id)); ?>">Show</a> -->
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
                                            <a class="btn btn-primary" href="<?php echo e(route('permissions.edit',$permission->id)); ?>">Edit</a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>
                                            <?php echo Form::open(['method' => 'DELETE','route' => ['permissions.destroy', $permission->id],'style'=>'display:inline']); ?>

                                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                                            <?php echo Form::close(); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </tbody>
                    </table>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Row -->

    </div>
	


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<!-- Data Table js -->
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/jquery.dataTables.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/js/table-data.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/dataTables.responsive.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/dataTables.buttons.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/buttons.bootstrap4.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/jszip.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/pdfmake.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/vfs_fonts.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/buttons.html5.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/buttons.print.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/buttons.colVis.min.js"></script>
<script type="text/javascript">
        $(function () {
          
          var table = $('#exportexample1').DataTable({
            dom: 'lBfrtip',
            buttons: [
               { 
                  extend: 'excel',
                  text: 'Permission Excel Export'
               }
            ],
            lengthMenu: [[25, 100, -1], [25, 100, "All"]],
          });
          
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u649628429/domains/vdwebinfotech.in/public_html/paymentcollection/resources/views/permissions/index.blade.php ENDPATH**/ ?>