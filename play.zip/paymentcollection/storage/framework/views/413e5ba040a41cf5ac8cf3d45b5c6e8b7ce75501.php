<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="justify-content-center">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Opps!</strong> Something went wrong, please check below errors.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">Create user
                <span class="float-right">
                    <a class="btn btn-primary" href="<?php echo e(route('users.index')); ?>">Users</a>
                </span>
            </div>

            <div class="card-body">
                <?php echo Form::model($post, ['route' => ['users.update', $post->id], 'method'=>'PATCH']); ?>

                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <strong>Name<span style="color:red;">*</span></strong>
                            <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control','required'=>'required')); ?>

                        </div>
                    </div> 
                    <div class="col-md-3">
                        <div class="form-group">
                            <strong>Email<span style="color:red;">*</span></strong>
                            <?php echo Form::email('email', null, array('placeholder' => 'Email','class' => 'form-control','required'=>'required')); ?>

                        </div>
                    </div>   
                    <div class="col-md-3">
                        <div class="form-group">
                            <strong>Contact<span style="color:red;">*</span></strong>
                            <?php echo Form::number('contact', null, array('placeholder' => 'Contact','class' => 'form-control','required'=>'required')); ?>

                        </div>
                    </div>   
                    <div class="col-md-3">
                        <div class="form-group">
                            <strong>Designation<span style="color:red;">*</span></strong>
                            <?php echo Form::text('designation', null, array('placeholder' => 'Designation','class' => 'form-control','required'=>'required')); ?>

                        </div>
                    </div>   
                    <div class="col-md-12">
                        <div class="form-group">
                            <strong>Address<span style="color:red;">*</span></strong>
                            <?php echo Form::textarea('address', null, array('placeholder' => 'Address','class' => 'form-control','required' =>'required')); ?>

            
                        </div>
                    </div>    
                    <div class="col-md-3">
                        <div class="form-group">
                            <strong>Password<span style="color:red;">*</span></strong>
                            <?php echo Form::password('password', array('placeholder' => 'Password','class' => 'form-control')); ?>

                        </div>
                    </div>    
                    <div class="col-md-3">
                        <div class="form-group">
                            <strong>Confirm Password<span style="color:red;">*</span></strong>
                            <?php echo Form::password('password_confirmation', array('placeholder' => 'Confirm Password','class' => 'form-control')); ?>

                        </div>
                    </div>                       
                    <div class="col-md-3">
                        <div class="form-group">
                            <strong>Role<span style="color:red;">*</span></strong>
                            <?php echo Form::select('roles[]', $roles, $userRole, array('class' => 'form-control js-example-basic-single','required'=>'required')); ?>

                  
                        </div>
                    </div>   
                   
                    
                </div>    
                    <button type="submit" class="btn btn-primary">Submit</button>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script type="text/javascript">
    
$(document).ready(function() {
    $('.js-example-basic-single').select2();
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u649628429/domains/vdwebinfotech.in/public_html/paymentcollection/resources/views/users/edit.blade.php ENDPATH**/ ?>