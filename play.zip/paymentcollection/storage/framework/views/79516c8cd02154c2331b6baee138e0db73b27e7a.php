<?php $__env->startSection('title'); ?>
<title>User</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
      <!-- Page Header -->
      <div class="page-header">
        <div>
            <h2 class="main-content-title tx-24 mg-b-5">Users</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Users</li>
            </ol>
        </div>
        
    </div>
    <!-- End Page Header -->

    <!-- Row-->
    <div class="row">
        <div class="col-sm-12 col-xl-12 col-lg-12">
            <div class="card custom-card">
                <div class="card-body">
                    <div>
                   
                        <h6 class="card-title mb-1">Users</h6>
                        <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e(\Session::get('success')); ?></p>
                            </div>
                        <?php endif; ?>
                        
                            <span class="float-right">
                                <a class="btn btn-primary" href="<?php echo e(route('users.create')); ?>">Create Users</a>
                            </span>
                        
                    </div>
                    <div class="table-responsive">

                    
                    <table id="exportexample1" class="table-bordered text-nowrap mb-0 table table-bordered border-t0 key-buttons text-nowrap w-100" >
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Roles</th>
                                <th>Status</th>
                                <th width="280px">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->id); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <?php if(!empty($user->getRoleNames())): ?>
                                        <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="badge badge-dark"><?php echo e($val); ?></label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($user->status == 1): ?>
                                        <label class="switch">
                                        <input type="checkbox" checked class="statuschange" status="<?php echo e($user->status); ?>" id="<?php echo e($user->id); ?>">
                                        <span class="slider round"></span>
                                        </label>
                                    <?php else: ?>
                                        <label class="switch">
                                        <input type="checkbox" class="statuschange" status="<?php echo e($user->status); ?>" id="<?php echo e($user->id); ?>">
                                        <span class="slider round"></span>
                                        </label>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <!-- <a class="btn btn-success" href="<?php echo e(route('users.show',$user->id)); ?>">Show</a> -->
                                    <a class="btn btn-primary" href="<?php echo e(route('users.edit',$user->id)); ?>">Edit</a>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-edit')): ?>
                                       
                                
                                        <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-delete')): ?>
                                        <?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']); ?>

                                        <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                                        <?php echo Form::close(); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </tbody>
                    </table>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Row -->

    </div>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Data Table js -->
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/jquery.dataTables.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/js/table-data.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/dataTables.responsive.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/dataTables.buttons.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/buttons.bootstrap4.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/jszip.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/pdfmake.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/vfs_fonts.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/buttons.html5.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/buttons.print.min.js"></script>
<script src="<?php echo e(URL::to('/')); ?>/assets/plugins/datatable/fileexport/buttons.colVis.min.js"></script>

 <script>
    var table = '';
    $(document).ready(function () {

        table = $('#exportexample1').DataTable({
            dom: 'lBfrtip',
            buttons: [
               { 
                  extend: 'excel',
                  text: 'Users Excel Export'
               }
            ],
            lengthMenu: [[25, 100, -1], [25, 100, "All"]],
          });
        $(document).on('click','.statuschange',function(){
   
            var id = $(this).attr('id');
            var status = $(this).attr('status');
            $.ajax({
                    
                    type: "get",
                    "url": "<?php echo e(route('users-statuschange')); ?>",
                    data:{id: id,status:status},
                    success: function (res) {
                }
            });

            });
    });


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u649628429/domains/vdwebinfotech.in/public_html/paymentcollection/resources/views/users/index.blade.php ENDPATH**/ ?>